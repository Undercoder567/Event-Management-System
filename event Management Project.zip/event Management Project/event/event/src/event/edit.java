
package event;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Vector;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class edit extends javax.swing.JFrame {

    /**
     * Creates new form edit
     */
    
    public edit()
{
        initComponents();
        Connect();
        //loadRoom();
        
        
    } 
     Connection Con;
    PreparedStatement pst;
    DefaultTableModel d;
    private int personId;
    
    public void Connect()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Con = DriverManager.getConnection("jdbc:mysql://localhost/event","root","");
             
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(reservation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(reservation.class.getName()).log(Level.SEVERE, null, ex);
           
        }
    }
     int loadRoom(String s){
        int c;
        //String Ref=txtRef.getText();
        try {
            pst=Con.prepareStatement("select * from reservation where Rid='"+s+"'");
            ResultSet rs=pst.executeQuery();
            ResultSetMetaData rsd=rs.getMetaData();
            c=rsd.getColumnCount();
            
            d=(DefaultTableModel)jTable1.getModel();
            d.setRowCount(0);
            while (rs.next())
            {
                Vector v2=new Vector();
                
                for (int i=1;i<=c;i++)
                {
                    v2.add(rs.getString("id"));
                    v2.add(rs.getString("Rid"));
                    v2.add(rs.getString("Name"));
                    v2.add(rs.getString("Address"));
                    v2.add(rs.getString("PhoneNo"));
                    v2.add(rs.getString("Date"));
                    v2.add(rs.getString("TimeSlot"));
                    v2.add(rs.getString("RoomID"));
                }
                d.addRow(v2);
                JOptionPane.showMessageDialog(this,"Room Booking found!!!!!");
           
           
           }
            
            
           
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(reservation.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        return 0;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        txtName3 = new javax.swing.JTextField();
        txtAddress3 = new javax.swing.JTextField();
        txtPhoneNo3 = new javax.swing.JTextField();
        txtTimeSlot3 = new javax.swing.JComboBox<>();
        txtDate3 = new com.toedter.calendar.JDateChooser();
        jLabel33 = new javax.swing.JLabel();
        txtRoomNo3 = new javax.swing.JComboBox<>();
        txtRef = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1300, 900));
        setPreferredSize(new java.awt.Dimension(1380, 900));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(153, 0, 0), new java.awt.Color(51, 0, 51), new java.awt.Color(102, 0, 204), new java.awt.Color(0, 102, 0)));

        jButton1.setFont(new java.awt.Font("Agency FB", 1, 18)); // NOI18N
        jButton1.setText("Back");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Candara", 1, 48)); // NOI18N
        jLabel1.setText("Edit Booking");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 627, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jButton1))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(40, 20, 1070, 88);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "id", "Rid", "Name", "Address", "PhoneNo", "Date", "TimeSlot", "RoomID"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(10, 119, 900, 617);

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));
        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel27.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        jLabel27.setText("Room No");

        jLabel28.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        jLabel28.setText("Name");

        jLabel29.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        jLabel29.setText("Address");

        jLabel30.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        jLabel30.setText("Phone No");

        jLabel31.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        jLabel31.setText("Date");

        jLabel32.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        jLabel32.setText("Time Slot");

        txtAddress3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtAddress3ActionPerformed(evt);
            }
        });

        txtPhoneNo3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPhoneNo3ActionPerformed(evt);
            }
        });

        txtTimeSlot3.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        txtTimeSlot3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "10:00-12:00", "12:00-2:00", "2:00-4:00", "4:00-6:00", " ", " " }));
        txtTimeSlot3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimeSlot3ActionPerformed(evt);
            }
        });

        txtDate3.setMaxSelectableDate(new java.util.Date(1893439868000L));
        txtDate3.setMinSelectableDate(new java.util.Date(1626982268000L));

        jLabel33.setFont(new java.awt.Font("Candara", 1, 24)); // NOI18N
        jLabel33.setText("Reference ID");

        txtRoomNo3.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        txtRoomNo3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Room 1 AC+Projector", "Room 2 AC+Projector", "Room 3 AC+Projector", "Room 4 ", "Room 5" }));

        txtRef.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRefActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setText("Go");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(102, 102, 102));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 0, 0));
        jButton3.setText("Delete");
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(51, 0, 102));
        jButton4.setText("Update");
        jButton4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel29)
                            .addComponent(jLabel28)
                            .addComponent(jLabel30)
                            .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel32)
                                .addComponent(jLabel27)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jLabel33))
                        .addGap(36, 36, 36)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtName3)
                    .addComponent(txtAddress3)
                    .addComponent(txtRef)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtPhoneNo3, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDate3, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTimeSlot3, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtRoomNo3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(91, 91, 91))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(99, 99, 99))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(txtRef)
                        .addGap(8, 8, 8)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel33)
                        .addGap(43, 43, 43)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtName3))
                .addGap(31, 31, 31)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel29)
                        .addGap(52, 52, 52)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel30)
                            .addComponent(txtPhoneNo3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(txtAddress3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDate3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(txtTimeSlot3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(txtRoomNo3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel5);
        jPanel5.setBounds(920, 120, 417, 605);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/event/cool-background-6.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        jLabel2.setAlignmentY(0.0F);
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 1360, 750);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         menu m=new menu();
         this.hide();
         m.setVisible(true);
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
         try{
             personId=Integer.parseInt(jTable1.getValueAt(jTable1.getSelectedRow(),0).toString());
            pst=Con.prepareStatement("select * from reservation where id="+personId);
            ResultSet rs=pst.executeQuery();
            if(rs.next())
            {d=(DefaultTableModel)jTable1.getModel();
        int selectIndex=jTable1.getSelectedRow();
                txtRef.setText(d.getValueAt(selectIndex,1).toString());
        txtName3.setText(d.getValueAt(selectIndex, 2).toString());
        txtAddress3.setText(d.getValueAt(selectIndex, 3).toString());
        txtPhoneNo3.setText(d.getValueAt(selectIndex, 4).toString());
                SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
        try{
            txtDate3.setDate(df.parse((d.getValueAt(selectIndex,5).toString())));
        }
        catch(Exception e){
            e.printStackTrace();
        }
                 txtTimeSlot3.setSelectedItem(d.getValueAt(selectIndex, 6).toString());
        txtRoomNo3.setSelectedItem(d.getValueAt(selectIndex, 7).toString());
            }
            rs.close();
            pst.close();
         }catch(Exception ex)
         {
             JOptionPane.showMessageDialog(this, ex);
         }
    
    }//GEN-LAST:event_jTable1MouseClicked

    private void txtAddress3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtAddress3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtAddress3ActionPerformed

    private void txtPhoneNo3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPhoneNo3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPhoneNo3ActionPerformed

    private void txtTimeSlot3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimeSlot3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimeSlot3ActionPerformed

    private void txtRefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRefActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRefActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        String Ref=txtRef.getText();
        if (txtRef.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(this, "**** Enter REFERENCE ID !!!!");
            
        }
         loadRoom(Ref);
    }//GEN-LAST:event_jButton2ActionPerformed
public void loadRoom(){
        int c;
        try {
            pst=Con.prepareStatement("select * from reservation ");
            ResultSet rs=pst.executeQuery();
            
            ResultSetMetaData rsd=rs.getMetaData();
            c=rsd.getColumnCount();
            
            d=(DefaultTableModel)jTable1.getModel();
            d.setRowCount(0);
            while (rs.next())
            {
                Vector v2=new Vector();
                
                for (int i=1;i<=c;i++)
                {
                    v2.add(rs.getString("id"));
                    v2.add(rs.getString("Rid"));
                    v2.add(rs.getString("Name"));
                    v2.add(rs.getString("Address"));
                    v2.add(rs.getString("PhoneNo"));
                    v2.add(rs.getString("Date"));
                    v2.add(rs.getString("TimeSlot"));
                    v2.add(rs.getString("RoomID"));
                }
                d.addRow(v2);
           }    
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(reservation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
//delete button
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       if(personId!=0)
       {
           try{
               pst=Con.prepareStatement("delete from reservation  where id="+ personId );
       pst.executeUpdate();
              JOptionPane.showMessageDialog(this,"Record Deleted ");
             
              txtRef.setText("");
       txtName3.setText("");
       txtAddress3.setText("");        
       txtPhoneNo3.setText("");        
       txtTimeSlot3.setSelectedIndex(-1);        
       txtRoomNo3.setSelectedIndex(-1);
        loadRoom();
       personId=0;
       pst.close();
       
       
           }catch(Exception ex)
           {
              JOptionPane.showMessageDialog(this,"Can Not Delete Record"); 
           }
       }
    }//GEN-LAST:event_jButton3ActionPerformed


// update button
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
             
        if(personId!=0)
                 {
                     String Ref=txtRef.getText();
               String Name3=txtName3.getText();
                 String TimeSlot3=txtTimeSlot3.getSelectedItem().toString();
               String Address3=txtAddress3.getText();
                   String PhoneNo3=txtPhoneNo3.getText();
                    String RoomNo3=txtRoomNo3.getSelectedItem().toString();
                   SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd");
                    String Date3=df.format(txtDate3.getDate());
                    if (txtRef.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(this, "Enter REFERENCE ID !!!!");
        }
           else try{
               {pst=Con.prepareStatement("select * from reservation where  Date='"+Date3+"'and TimeSlot='"+TimeSlot3+"'and RoomID='"+RoomNo3+"'");
                ResultSet rs=pst.executeQuery();
        if(rs.next()==true)
       {
           JOptionPane.showMessageDialog(this,"Room already BOOKED!!!\n Please book another room!!!!!");
       }
        else
        {
          pst=Con.prepareStatement("update reservation set Rid='"+Ref+"',Date='"+Date3+"',TimeSlot='"+TimeSlot3+"',RoomID='"+RoomNo3+"' where id="+ personId );
       pst.executeUpdate();
      
       JOptionPane.showMessageDialog(this,"Room Detail updated !!!!!");/*Name='"+Name3+"',Address='"+Address3+"',PhoneNo='"+PhoneNo3+"',*/
       loadRoom(Ref);
       personId=0;
        } pst.close();
        rs.close();
             }
           }
                    catch (Exception ex) 
             {
            JOptionPane.showMessageDialog(this,"Can Not Update Record");
              }
                 }

    }//GEN-LAST:event_jButton4ActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
       /* try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(edit.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new edit().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txtAddress3;
    private com.toedter.calendar.JDateChooser txtDate3;
    private javax.swing.JTextField txtName3;
    private javax.swing.JTextField txtPhoneNo3;
    private javax.swing.JTextField txtRef;
    private javax.swing.JComboBox<String> txtRoomNo3;
    private javax.swing.JComboBox<String> txtTimeSlot3;
    // End of variables declaration//GEN-END:variables
}
